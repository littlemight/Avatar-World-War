#include "pcolor.h"

int main() {
    print_red('r'); printf("\n");
    print_green('g'); printf("\n");
    print_blue('b'); printf("\n");
    print_magenta('m'); printf("\n");
    print_yellow('y'); printf("\n");
    return 0;
}