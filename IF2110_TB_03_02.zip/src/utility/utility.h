#ifndef Utility_H
#define Utility_H

void LineBr();
void PrintCWD();
void clear();

#endif