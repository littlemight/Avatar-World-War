# Avatar World War
## Program Utama
Untuk menjalankan program, dapat mengetikkan perintah berikut di directory root dari folder ini
```
run
```

## Driver ADT
Driver setiap program dapat dijalankan dengan menjalankan perintah berikut di command line
```
> rundriver <nama adt>
```

### Contoh
```
> rundriver point
Compiling driver for point...
Compilation done 
Press any key to continue . . . 

Masukkin 2 angka: 12 23
(12,23)
```

Script yang digunakan adalah script batch yang hanya dapat bekerja di windows.

## Anggota Kelompok
1. Yudy Valentino (13517  128)
2. Faris Fadhillah (13518026)
3. Muhammad Ziad Rahmatullah (13518032)
4. Jones Napoleon Autumn (13518086)
5. Michel Fang (13518137)
6. Naufal Prima Yoriko (13518146)
